package com.unicesumar.repository;

import com.unicesumar.entities.Sale;
import com.unicesumar.entities.Product;
import com.unicesumar.entities.User;
import com.unicesumar.paymentMethods.PaymentType;

import java.sql.*;
import java.util.*;

public class SaleRepository implements EntityRepository<Sale> {
    private final Connection connection;

    public SaleRepository(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void save(Sale sale) {
        try {
            String insertSale = "INSERT INTO sales (uuid, user_uuid, payment_type) VALUES (?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(insertSale);
            stmt.setString(1, sale.getUuid().toString());
            stmt.setString(2, sale.getUser().getUuid().toString());
            stmt.setString(3, sale.getPaymentType().toString());
            stmt.executeUpdate();

            for (Product product : sale.getProducts()) {
                String insertProductSale = "INSERT INTO sale_products (sale_uuid, product_uuid) VALUES (?, ?)";
                PreparedStatement stmt2 = connection.prepareStatement(insertProductSale);
                stmt2.setString(1, sale.getUuid().toString());
                stmt2.setString(2, product.getUuid().toString());
                stmt2.executeUpdate();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override public Optional<Sale> findById(UUID id) { return Optional.empty(); }
    @Override public List<Sale> findAll() { return new ArrayList<>(); }
    @Override public void deleteById(UUID id) {}
}
