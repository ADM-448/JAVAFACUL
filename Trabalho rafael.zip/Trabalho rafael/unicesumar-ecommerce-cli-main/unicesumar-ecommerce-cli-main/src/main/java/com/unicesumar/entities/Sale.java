package com.unicesumar.entities;

import com.unicesumar.paymentMethods.PaymentType;

import java.util.List;
import java.util.UUID;

public class Sale extends Entity {
    private User user;
    private List<Product> products;
    private PaymentType paymentType;

    public Sale(User user, List<Product> products, PaymentType paymentType) {
        this.user = user;
        this.products = products;
        this.paymentType = paymentType;
    }

    public User getUser() {
        return user;
    }

    public List<Product> getProducts() {
        return products;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public double getTotal() {
        return products.stream().mapToDouble(Product::getPrice).sum();
    }
}
