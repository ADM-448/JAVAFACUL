package com.unicesumar;

import com.unicesumar.entities.Product;
import com.unicesumar.entities.Sale;
import com.unicesumar.entities.User;
import com.unicesumar.paymentMethods.*;
import com.unicesumar.repository.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        ProductRepository listaDeProdutos = null;
        UserRepository listaDeUsuarios = null;
        SaleRepository repositorioDeVendas = null;

        Connection conn = null;

        String url = "jdbc:sqlite:database.sqlite";

        try {
            conn = DriverManager.getConnection(url);
            if (conn != null) {
                listaDeProdutos = new ProductRepository(conn);
                listaDeUsuarios = new UserRepository(conn);
                repositorioDeVendas = new SaleRepository(conn);
            } else {
                System.out.println("Falha na conexão.");
                System.exit(1);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao conectar: " + e.getMessage());
            System.exit(1);
        }

        Scanner scanner = new Scanner(System.in);
        int option;

        do {
            System.out.println("\n---MENU---");
            System.out.println("1 - Cadastrar Produto");
            System.out.println("2 - Listar Produtos");
            System.out.println("3 - Cadastrar Usuário");
            System.out.println("4 - Listar Usuários");
            System.out.println("5 - Registrar Venda");
            System.out.println("6 - Sair");
            System.out.print("Escolha uma opção: ");
            option = scanner.nextInt();

            switch (option) {
                case 1:
                    System.out.println("Cadastrar Produto");
                    listaDeProdutos.save(new Product("Camiseta", 50));
                    listaDeProdutos.save(new Product("Tênis", 200));
                    break;
                case 2:
                    System.out.println("Listar Produtos");
                    List<Product> products = listaDeProdutos.findAll();
                    products.forEach(System.out::println);
                    break;
                case 3:
                    System.out.println("Cadastrar Usuário");
                    listaDeUsuarios.save(new User("João da Silva", "joao@example.com", "senha123"));
                    break;
                case 4:
                    System.out.println("Listar Usuários");
                    List<User> users = listaDeUsuarios.findAll();
                    users.forEach(System.out::println);
                    break;
                case 5:
                    scanner.nextLine(); // Limpar buffer
                    System.out.print("Digite o email do usuário: ");
                    String email = scanner.nextLine();

                    Optional<User> optUser = listaDeUsuarios.findAll().stream()
                            .filter(u -> u.getEmail().equalsIgnoreCase(email))
                            .findFirst();

                    if (optUser.isEmpty()) {
                        System.out.println("Usuário não encontrado.");
                        break;
                    }

                    User cliente = optUser.get();
                    System.out.println("Usuário encontrado: " + cliente.getName());

                    System.out.print("Digite os UUIDs dos produtos (separados por vírgula): ");
                    String[] uuids = scanner.nextLine().split(",");

                    List<Product> produtosSelecionados = new ArrayList<>();
                    for (String uuidStr : uuids) {
                        try {
                            UUID uuid = UUID.fromString(uuidStr.trim());
                            Optional<Product> prod = listaDeProdutos.findById(uuid);
                            prod.ifPresent(produtosSelecionados::add);
                        } catch (IllegalArgumentException e) {
                            System.out.println("UUID inválido: " + uuidStr);
                        }
                    }

                    if (produtosSelecionados.isEmpty()) {
                        System.out.println("Nenhum produto válido selecionado.");
                        break;
                    }

                    System.out.println("Produtos selecionados:");
                    double total = 0;
                    for (Product p : produtosSelecionados) {
                        System.out.printf("- %s (R$ %.2f)%n", p.getName(), p.getPrice());
                        total += p.getPrice();
                    }

                    System.out.println("Escolha a forma de pagamento:");
                    System.out.println("1 - Cartão de Crédito");
                    System.out.println("2 - Boleto");
                    System.out.println("3 - PIX");
                    int metodo = scanner.nextInt();

                    PaymentType tipoPagamento = null;
                    switch (metodo) {
                        case 1:
                            tipoPagamento = PaymentType.CARTAO;
                            break;
                        case 2:
                            tipoPagamento = PaymentType.BOLETO;
                            break;
                        case 3:
                            tipoPagamento = PaymentType.PIX;
                            break;
                        default:
                            System.out.println("Forma de pagamento inválida.");
                            break;
                    }

                    PaymentMethod metodoPagamento = PaymentMethodFactory.create(tipoPagamento);
                    PaymentManager manager = new PaymentManager();
                    manager.setPaymentMethod(metodoPagamento);
                    manager.pay(total);

                    Sale venda = new Sale(cliente, produtosSelecionados, tipoPagamento);
                    repositorioDeVendas.save(venda);

                    System.out.println("\nResumo da venda:");
                    System.out.println("Cliente: " + cliente.getName());
                    for (Product p : produtosSelecionados) {
                        System.out.println("- " + p.getName());
                    }
                    System.out.printf("Valor total: R$ %.2f%n", total);
                    System.out.println("Pagamento: " + tipoPagamento);
                    System.out.println("Venda registrada com sucesso!");
                    break;

                case 6:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }

        } while (option != 6);

        scanner.close();
        try {
            conn.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
